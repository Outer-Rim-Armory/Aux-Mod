class Sound;
class BNA_KC_Sound_Deploy: Sound
{
	author = "JRY";
    scope = 1;
    sound = "BNA_KC_SFX_Deploy";
    displayName = "Deploy SFX";
};
class BNA_KC_Sound_Undeploy: Sound
{
	author = "JRY";
    scope = 1;
    sound = "BNA_KC_SFX_Undeploy";
    displayName = "Undeploy SFX";
};
class BNA_KC_Sound_HealLoop: Sound
{
	author = "JRY";
    scope = 1;
    sound = "BNA_KC_SFX_HealLoop";
    displayName = "Heal SFX Loop";
};
class BNA_KC_Sound_RepairLoop: Sound
{
    author = "JRY";
    scope = 1;
    sound = "BNA_KC_SFX_HealLoop";
    displayName = "Repair SFX Loop";
};