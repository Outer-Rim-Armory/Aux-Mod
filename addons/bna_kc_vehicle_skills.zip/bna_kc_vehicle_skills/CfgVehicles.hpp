class CfgVehicles
{
    #include "sounds\sounds.hpp"
    #include "land\gammoth\gammoth.hpp"
    #include "land\hermitaur\hermitaur.hpp"
    #include "land\hydra\hydra.hpp"
    #include "land\juggernaut\juggernaut.hpp"
    #include "land\khezu\khezu.hpp"
    #include "land\reek\reek.hpp"
    #include "land\tx130\tx130.hpp"
    #include "air\nu\nu.hpp"
    #include "air\rho\rho.hpp"
};